<?php
error_reporting(0);
header("location:../index.php");
?>